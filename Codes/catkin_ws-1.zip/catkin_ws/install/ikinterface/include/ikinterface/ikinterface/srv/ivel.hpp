// generated from rosidl_generator_cpp/resource/idl.hpp.em
// generated code does not contain a copyright notice

#ifndef IKINTERFACE__SRV__IVEL_HPP_
#define IKINTERFACE__SRV__IVEL_HPP_

#include "ikinterface/srv/detail/ivel__struct.hpp"
#include "ikinterface/srv/detail/ivel__builder.hpp"
#include "ikinterface/srv/detail/ivel__traits.hpp"

#endif  // IKINTERFACE__SRV__IVEL_HPP_
