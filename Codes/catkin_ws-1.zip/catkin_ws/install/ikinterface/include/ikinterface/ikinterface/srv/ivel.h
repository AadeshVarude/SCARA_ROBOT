// generated from rosidl_generator_c/resource/idl.h.em
// with input from ikinterface:srv/Ivel.idl
// generated code does not contain a copyright notice

#ifndef IKINTERFACE__SRV__IVEL_H_
#define IKINTERFACE__SRV__IVEL_H_

#include "ikinterface/srv/detail/ivel__struct.h"
#include "ikinterface/srv/detail/ivel__functions.h"
#include "ikinterface/srv/detail/ivel__type_support.h"

#endif  // IKINTERFACE__SRV__IVEL_H_
